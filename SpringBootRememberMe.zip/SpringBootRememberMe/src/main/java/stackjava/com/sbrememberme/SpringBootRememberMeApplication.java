package stackjava.com.sbrememberme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRememberMeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRememberMeApplication.class, args);
	}
}
